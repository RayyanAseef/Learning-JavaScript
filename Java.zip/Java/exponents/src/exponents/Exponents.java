/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exponents;

import java.util.Scanner;

/**
 *
 * @author S300062235
 */
public class Exponents {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Made an input variable
        Scanner keyedInput = new Scanner(System.in);
        
        // Decalring variables
        int num;
        int startNum;
        int power;
        int choice = 0;
        
        // Made a while loop until the user wants to end the program
        //(They close the program from picking 4 from their menu inside the loop)
        while (choice != 4) {
            // Set the Manditory instructions to the user along with the menu
            System.out.println("Pick a number bellow from the menu for what you want to do.");
            System.out.println("Menu:\n");
            System.out.println("1 = Find the value of a number squared");
            System.out.println("2 = Find the value of a number cubed");
            System.out.println("3 = Find the value of a number, to any power");
            System.out.println("4 = Exit");
            
            // Ask the user to choose what they want from the menu
            System.out.print("\nYour Choice: ");
            choice = keyedInput.nextInt();
            
            // This if staement is for when they choose 1 from the menu
            if (choice == 1) {
                // This line just states what they picked (1)
                System.out.println("\nYou Picked 1:\n");
                
                // Asks the user their number
                System.out.print("Your Number: ");
                startNum = keyedInput.nextInt();
                num = startNum;
                
                // This for loop is to square their number
                for (int i = 1;i < 2; i = i + 1) {
                    num = num * startNum;
                }
                
                // To display there squared number on the screen
                System.out.println(startNum + " squared is " + num + "\n");
            }
            
            // This if staement is for when they choose 2 from the menu
            else if (choice == 2) {
                // This line just states what they picked (2)
                System.out.println("\nYou Picked 2:\n");
                
                // Asks the user their number
                System.out.print("Your Number: ");
                startNum = keyedInput.nextInt();
                num = startNum;
                
                // This for loop is to cube their number
                for (int i = 1;i < 3; i = i + 1) {
                    num = num * startNum;
                }
                
                // To display there cubed number on the screen
                System.out.println(startNum + " cubed is " + num + "\n");
            }
            
            // This if staement is for when they choose 3 from the menu
            else if (choice == 3) {
                // This line just states what they picked (3)
                System.out.println("\nYou Picked 3:\n");
                
                // Asks the user their number
                System.out.print("Your Number: ");
                startNum = keyedInput.nextInt();
                num = startNum;
                
                // Asks the user their exponent/power
                System.out.print("Your Power: ");
                power = keyedInput.nextInt();
                
                // This for loop powers their number they picked with the exponent they picked
                for (int i = 1;i < power; i = i + 1) {
                    num = num * startNum;
                }
                
                // Displays the answer to what their number is powered by their exponent
                System.out.println(startNum + " powered by " + power + " is " + num + "\n");
            }
            
            // This if staement is for when they choose 4 from the menu
            else if (choice == 4) {
                // This line just states what they picked (4)
                System.out.println("\nYou Picked 4:\n");
                
                //Farewell message before closing the program
                //(The program closes because the while loop closes when they pick 4 from the menu)
                System.out.println("Thank you for using this program. See you again.");
            }
            // This is for when they pick an number that is not from 1 to 4
            else {
                // Displays an  error message to the user that they did not pick a number from the menu
                System.out.println("\nThat is not an option listed in the menu");
            }
        }
    }
    
}
