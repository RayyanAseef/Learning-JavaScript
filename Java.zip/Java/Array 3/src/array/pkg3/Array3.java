/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array.pkg3;

/**
 *
 * @author User
 */
public class Array3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Decalaring the variables
        double [] marks = {34.7, 54.1, 34.8, 99.6, 43.6, 43.2, 65.8, 44.8, 88.6};
        double total = 0;
        double average;
        
        // Telling the user what are the numbers we are showing to them
        System.out.println("These are the marks:\n");
        
        // SHowing the user the numbers inside of the varable marks
        for (int i = 0;i <= 8; i = i + 1) {
            System.out.println(marks[i]);
        } 
        // Adding the marks all together
        for (int i = 0;i <= 8; i = i + 1) {
            total = total + marks[i];
        }
        
        // getting the average of the marks
        average = total/6;
        average = average * 10;
        average = Math.round(average);
        average = average / 10;
        
        // Telling the user the average of the marks
        System.out.println("\nThe average mark is " + average);
    }
    
}
