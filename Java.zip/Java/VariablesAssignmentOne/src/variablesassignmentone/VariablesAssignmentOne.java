/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package variablesassignmentone;

/**
 *
 * @author S300062235
 */
public class VariablesAssignmentOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int age;
        double PI;
        String message;
        boolean boy;
        
        age = 16;
        PI = 3.14;
        message = "Hello World";
        boy = true;
        
        System.out.println("Hello I am Rayyan and my age is " + age + ".");
        System.out.println("PI is " + PI + ".");
        System.out.println("I would like to say " + message + ".");
        System.out.println("Am I a boy: " + boy);
          
    }
    
}
