/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package purchaseifelseassignment;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class PurchaseIfElseAssignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner keyedInput = new Scanner(System.in);
        
        double spent;
        
        System.out.print("Enter the amount spent: ");
        spent = keyedInput.nextInt();
        
        if (0.01 <= spent) {
            
            if (spent <= 40.00) {
                System.out.println("\nYou have received 10% off");
                spent = spent * 0.9;
                spent = spent * 100;
                spent = Math.round(spent);
                spent = spent / 100;
                System.out.println("Your total is " + spent);
            }
            
            if  (40.01 <= spent) {
                if (spent <= 80.00) {
                    System.out.println("\nYou have received 20% off");
                    spent = spent * 0.8;
                    spent = spent * 100;
                    spent = Math.round(spent);
                    spent = spent / 100;
                    System.out.println("Your total is " + spent);
                }
                
                if (80.01 <= spent) {
                    if (spent <= 120.00) {
                        System.out.println("\nYou have received 30% off");
                        spent = spent * 0.7;
                        spent = spent * 100;
                        spent = Math.round(spent);
                        spent = spent / 100;
                        System.out.println("Your total is " + spent);
                    }
                    
                    if (120.01 <= spent) {
                        System.out.println("\nYou have received 40% off");
                        spent = spent * 0.6;
                        spent = spent * 100;
                        spent = Math.round(spent);
                        spent = spent / 100;
                        System.out.println("Your total is " + spent);
                    }
                    
                }
                
            }
            
        }
    }
          
}
