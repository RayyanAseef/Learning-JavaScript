

public class binHexGUI extends javax.swing.JFrame {

    public binHexGUI() {
        initComponents();
    }
    
    // Making method to find teh largest digit in a binary or hexadeciam lnumber
    public static int larDigitFind(int DecNum,String Type) {
        
        // Decalring variable
        int LarDig = 0;
        
        // If statement to check if we are finding binary's largest digit 
        if (Type == "bin") {
            // Using for loop to get largest digit
            for (int i = LarDig;i <= DecNum; i = LarDig) {
                // IF the lat=rgest digit is zer0 add one
                if (LarDig == 0) {
                    LarDig = 1;
                }
                // Multiply the largest digit by  2 every loop
                else {
                    LarDig = LarDig * 2;
                }
            }
            
            // The largest digit in the for loop is usually double the actually answer so we divide it by 2
            LarDig = LarDig / 2;
        }
        
        // If statement to check if we are finding hexadecimal's largest digit 
        else if (Type == "hex") {
            // Using for loop to get largest digit
            for (int i = LarDig;i <= DecNum; i = LarDig) {
                // if largest number is 0 add 1
                if (LarDig == 0) {
                    LarDig = 1;
                }
                // else multiply by 16
                else {
                    LarDig = LarDig * 16;
                }
            }
            
            // The largest digit in the for loop is usually times 16 the actually answer so we divide it by 16
            LarDig = LarDig / 16;
        }
        
        // Returning the answer
        return LarDig;
        
    }
    
    // Making a method to find the binary number
    public static String binNumFind(int LarDig,int DecNum) {
        
        // Decalring variable
        int digitValue;
        String BinNum = "";
        
        // For loop to find binary number from decimal number
        for (int i = LarDig;i >= 1; i = LarDig) {
            // if decimal number is bigger or equal this digit is 1 
            if (DecNum >= LarDig) {
                // Subtracting Decimal number with largest digit
                DecNum = DecNum - LarDig;
                digitValue = 1;
            }
            // else digit this digit is 0
            else {
                digitValue = 0;
            }
            
            // Divideing largest digit by 2
            LarDig = LarDig / 2;
            
            // putting the digit number in tge binary number string
            BinNum = BinNum + digitValue;
        }
        
        // Returning the answer
        return BinNum;
        
    }
    
    // Making a method to get the hexadecimal number
    public static String hexNumFind(int LarDig,double DecNum) {
        
        // Decalring variable
        double digitValue;
        String digitValueStr = "";
        String HexNum = "";
        
        // for loop to find hexdecimal number from decimal number
        for (int i = LarDig;i >= 1; i = LarDig) {
            // if decimal number is bigger than largest number 
            if (DecNum >= LarDig) {
                // the digit is decimal number divided by largest number divided down
                digitValue = DecNum / LarDig;
                digitValue = Math.floor(digitValue);
                
                // deciam number equals deciam lnumber subtract (largest number multiplied by its value)
                DecNum = DecNum - (LarDig * digitValue);
            }
            // else digit is 0
            else {
                digitValue = 0;
            }
            
            // divide largest ndigit by 16 
            LarDig = LarDig / 16;
            
            // if digit is 10 to 15
            switch ((int)digitValue) {
                // if digit is 10 it equals A
                case 10:
                    digitValueStr = "A";
                    break;
                // if digit is 10 it equals B
                case 11:
                    digitValueStr = "B";
                    break;
                // if digit is 10 it equals C
                case 12:
                    digitValueStr = "C";
                    break;
                // if digit is 10 it equals D
                case 13:
                    digitValueStr = "D";
                    break;
                // if digit is 10 it equals E
                case 14:
                    digitValueStr = "E";
                    break;
                // if digit is 10 it equals F
                case 15:
                    digitValueStr = "F";
                    break;
            } 
            
            // if digit value is smaller than 10
            if (digitValue < 10) {
                // add number digit int on to HexNum string
                HexNum = HexNum + (int)digitValue;
            }
            // if digit value is more bigger than 9
            else if (digitValue > 9) {
                // add number digit str on to HexNum string
                HexNum = HexNum + digitValueStr;
            }
        }
        
        // Returning the answer
        return HexNum;
        
    }
    
    // Making a method to find the Decimal number from binary
    public static double deciNumFindBin(int binNum) {
        
        // Decalring variable
        String numDigit;
        int numDigitCon;
        
        char numInDigitStr;
        int numInDigitInt;
        int i2 = 0; 
        
        double DecNum = 0;
        
        // Getting number of digits in binary number
        numDigit = String.valueOf(binNum);
        numDigitCon = numDigit.length();
        
        // for loop to find decimal number from binary
        for (int i = numDigitCon; i >= 1; i = i - 1) {
            // getting the digits left to right
            numInDigitStr = numDigit.charAt(i2);
            numInDigitInt = Character.getNumericValue(numInDigitStr);
            i2 = i2 + 1;
            
            // adding digits value to decimal number
            DecNum = DecNum + ((Math.pow(2,i-1)) * numInDigitInt);
        }
        
        // Returning the answer
        return DecNum;
        
    }
    
    // Making a method to find the Decimal number from hexadecimal
    public static int deciNumFindHex(String HexNum) {
        
        // Decalring variable
        String HexNumStr;
        int HexNumInt;
        double DecNum = 0;
        int value = 1;
        
        boolean flag;
        
        // getting number of digits in hexdecimal number
        int HexNumLen = HexNum.length();
        
        // for loop to get decimal value from hexdecimal
        for (int i = HexNumLen;i > 0;i = i - 1) {
            // Checking if each digit is number or letter
            flag = Character.isDigit(HexNum.charAt(i - 1));
            HexNumStr = String.valueOf(HexNum.charAt(i - 1));
            
            // if digit is number
            if (flag == true) {
                // Get digit into int variable
                HexNumInt = Integer.parseInt(HexNumStr);
                
                // adding hexdecimal digit value to decimal number
                DecNum = DecNum + (HexNumInt * value);
            }
            
            // if digit is letter 
            else if (flag == false) {
                // Checking what letter it is and deciding what the value of teh digit is decimal wise
                switch (HexNumStr) {
                    // if digit is "A" value is 10
                    case "A":
                        HexNumInt = 10;
                        break;
                    // if digit is "B" value is 10
                    case "B":
                        HexNumInt = 11;
                        break;
                    // if digit is "C" value is 10
                    case "C":
                        HexNumInt = 12;
                        break;
                    // if digit is "D" value is 10
                    case "D":
                        HexNumInt = 13;
                        break;    
                    // if digit is "E" value is 10
                    case "E":
                        HexNumInt = 14;
                        break;
                    // if digit is "F" value is 10
                    case "F":
                        HexNumInt = 15;
                        break;
                    // if none of them value is 0
                    default:
                        HexNumInt = 0;
                        break;
                }
                // adding digit value to decimal number
                DecNum = DecNum + (HexNumInt * value);
            }
            // Increasing value every loop
            value = value * 16;
        }
        
        // Returning the answer
        return (int)DecNum;
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        binToDec = new javax.swing.JTextField();
        decToBin = new javax.swing.JTextField();
        hexToDec = new javax.swing.JTextField();
        decToHex = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnBinDec = new javax.swing.JButton();
        BtnDecHex = new javax.swing.JButton();
        btnDecBin = new javax.swing.JButton();
        btnHexDec = new javax.swing.JButton();
        decConvBin = new javax.swing.JLabel();
        binConvDec = new javax.swing.JLabel();
        decConvHex = new javax.swing.JLabel();
        hexConvDec = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Number Systems");

        jLabel2.setText("Enter a decimal number here:");

        jLabel3.setText("Enter a binary number here:");

        jLabel4.setText("Enter a decimal number here:");

        jLabel5.setText("Enter a hexadecimal number here:");

        binToDec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                binToDecActionPerformed(evt);
            }
        });

        decToBin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                decToBinActionPerformed(evt);
            }
        });

        hexToDec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hexToDecActionPerformed(evt);
            }
        });

        decToHex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                decToHexActionPerformed(evt);
            }
        });

        jLabel6.setText("Decimal and Binary");

        jLabel7.setText("Decimal and Hexadecimal");

        btnBinDec.setText("Bin to Dec");
        btnBinDec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBinDecActionPerformed(evt);
            }
        });

        BtnDecHex.setText("Dec to Hex");
        BtnDecHex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnDecHexActionPerformed(evt);
            }
        });

        btnDecBin.setText("Dec to Bin");
        btnDecBin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDecBinActionPerformed(evt);
            }
        });

        btnHexDec.setText("Hex to Dec");
        btnHexDec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHexDecActionPerformed(evt);
            }
        });

        decConvBin.setText("Unknown");

        binConvDec.setText("Unknown");

        decConvHex.setText("Unknown");

        hexConvDec.setText("Unknown");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(198, 198, 198)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(33, 33, 33)
                                .addComponent(hexToDec, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(57, 57, 57)
                                .addComponent(decToHex, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnDecHex)
                            .addComponent(btnHexDec)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addGap(57, 57, 57)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(binToDec, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(decToBin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBinDec, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnDecBin, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(147, 147, 147)
                        .addComponent(jLabel1)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(decConvBin)
                            .addComponent(binConvDec))
                        .addGap(28, 28, 28))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hexConvDec)
                            .addComponent(decConvHex))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(decToBin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDecBin)
                            .addComponent(decConvBin))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(binToDec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(btnBinDec)
                            .addComponent(binConvDec)))
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(decToHex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnDecHex)
                    .addComponent(decConvHex))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(hexToDec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHexDec)
                    .addComponent(hexConvDec))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void binToDecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_binToDecActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_binToDecActionPerformed

    private void decToBinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_decToBinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_decToBinActionPerformed

    private void hexToDecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hexToDecActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hexToDecActionPerformed

    private void decToHexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_decToHexActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_decToHexActionPerformed

    private void btnDecBinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDecBinActionPerformed
        
        // Decalring variables
        int larDigit;
        int deciNum;
        String binNum = "";
        
        // Getting the decimal number from the user
        deciNum = Integer.parseInt(decToBin.getText());
        
        // Getting the largest and binary number from methods
        larDigit = larDigitFind(deciNum,"bin");
        binNum = binNumFind(larDigit,deciNum);
        
        // To make sure that the string is never empty
        if (binNum == "") {
            binNum = "0";
        }
        
        // Telling the user the answer
        decConvBin.setText(binNum);
        
    }//GEN-LAST:event_btnDecBinActionPerformed

    private void btnBinDecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBinDecActionPerformed
        
        // Decalring variables
        int binNum;
        double deciNum;
        
        // Getting the binary number from the user
        binNum = Integer.parseInt(binToDec.getText());
        
        // Getting the Decimal number with a method
        deciNum = deciNumFindBin(binNum);
        
        // Telling teh user the answer
        binConvDec.setText(String.valueOf((int)deciNum));
        
    }//GEN-LAST:event_btnBinDecActionPerformed

    private void BtnDecHexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnDecHexActionPerformed
        
        // Decalring variables
        int deciNum;
        String hexNum;
        int larDigit;
        
        // Getting the decimal number from the user
        deciNum = Integer.parseInt(decToHex.getText());
        
        // Getting the largest digit and the hexdecimal number from methods 
        larDigit = larDigitFind(deciNum,"hex");
        hexNum = hexNumFind(larDigit,deciNum);
        
        // To make sure that the string is never empty
        if (hexNum == "" ) {
            hexNum = "0";
        }
        
        // Telling the user the answers
        decConvHex.setText(hexNum);
        
    }//GEN-LAST:event_BtnDecHexActionPerformed

    private void btnHexDecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHexDecActionPerformed
        
        // Decalring variables
        String hexNum;
        int deciNum;
        
        // Getting the hexadecimal number from the user
        hexNum = hexToDec.getText();
        
        // Using method to get decimal
        deciNum = deciNumFindHex(hexNum);
        
        // Telling the user the answer
        hexConvDec.setText(String.valueOf(deciNum));
        
    }//GEN-LAST:event_btnHexDecActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(binHexGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(binHexGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(binHexGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(binHexGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new binHexGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnDecHex;
    private javax.swing.JLabel binConvDec;
    private javax.swing.JTextField binToDec;
    private javax.swing.JButton btnBinDec;
    private javax.swing.JButton btnDecBin;
    private javax.swing.JButton btnHexDec;
    private javax.swing.JLabel decConvBin;
    private javax.swing.JLabel decConvHex;
    private javax.swing.JTextField decToBin;
    private javax.swing.JTextField decToHex;
    private javax.swing.JLabel hexConvDec;
    private javax.swing.JTextField hexToDec;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    // End of variables declaration//GEN-END:variables
}
