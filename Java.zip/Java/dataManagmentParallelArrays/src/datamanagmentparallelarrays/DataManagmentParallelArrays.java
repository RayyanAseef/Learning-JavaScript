
package datamanagmentparallelarrays;

import java.util.Scanner;

public class DataManagmentParallelArrays {
    
    // method to display menu
    public static void menu() {
        
        // Displaying menu
        System.out.println("1 = Display Win Lose Tie Satistices");
        System.out.println("2 = Display Win Lose Tie Percentages");
        System.out.println("3 = Exit");
        
    }
    
    // method to find out total games played
    public static double getTotalGames(double[] WLTInt) {
        
        // decalring variables
        double total = 0;
        
        // For loop to get total of number satistics
        /*New for loop method I found over the weekend. It goes through the given array and 
        i represents the number(In this case) in the array depending in which loop it is in*/
        for (double i: WLTInt) {
            // Adding each number in array to total
            total += i;
        }
        
        // returning answer
        return total;
        
    }
    
    // Mathod to get game percentages
    public static double[] getGamePerc(double[] WLTInt, double total) {
        
        // decalring variables
        double[] WLTPerc = new double[3];
        double num;
        
        // For loop to get all the percentages of win lose tie
        for (int i = 0;i < 3;i++) {
            // getting the percentage of win lose tie depending on the loop
            num = WLTInt[i] / total;
            num = num * 1000;
            num = Math.round(num);
            num = num / 10;
            
            // Storing the percentage in the percentage array
            WLTPerc[i] = num;
        }
        
        // returning answer
        return WLTPerc;
        
    }
    
    public static void main(String[] args) {
        
        // Making input variable
        Scanner input = new Scanner(System.in);
        
        // Making an array to keep the win lose tie string satistics
        String[] winLoseTieStr = {"Win: ","Lose: ","Tie: "};
        
        // Array to hold the number of the win lose tie satistics
        double[] winLoseTieInt = {33,12,4};
        
        // Gettingthe total number of games played
        double total = getTotalGames(winLoseTieInt);
        
        // Array to hold the percentages
        double[] winLoseTiePerc = new double[3];
        
        // Storing Percentages into the winLoseTiePerc Array 
        winLoseTiePerc = getGamePerc(winLoseTieInt,total);
        
        // Welcoming the user to the program
        System.out.println("Welcome to the Soccer Team \"Destroyers\" Win-Lose Satistics ");
        
        // decalring variables
        String choiceStr;
        int choiceInt = 0;
        
        while (choiceInt != 3) {
            System.out.println("__________");
            System.out.println("Chose one of the options from the menu bellow:\n");
            
            // Showing them the menu
            menu();
                
            // Telling them to pick there choice from teh menu
            System.out.print("\nChoice: ");
            choiceStr = input.next();
            
            try {
                choiceInt = Integer.parseInt(choiceStr);
            }
            catch (Exception e) {
                choiceInt = 0;
            }
            
            // if they pick one show the mthe win lose tie satistics
            if (choiceInt == 1) {
                System.out.println("");
                // for loop to show satistics
                for (int i = 0;i < 3;i++) {
                    // showing satistics
                    System.out.println(winLoseTieStr[i] + (int)winLoseTieInt[i]);
                }
            }
            
            // if they pick 2 show them the win lose tie percentages
            else if (choiceInt == 2) {
                System.out.println("");
                // For loop to show percentage
                for (int i = 0;i < 3;i++) {
                    // showing percentage
                    System.out.println(winLoseTieStr[i] + "%" +  winLoseTiePerc[i]);
                }
            }
            
            // if they pick 3 end the program
            else if (choiceInt == 3) {
                // Ending program
                break;
            }
            
            // else tell them they picked a wrong number
            else {
                // Giving them Invalid Answer Errror
                System.out.println("\nINVALID ANSWER");
            }
        }
        
    }
    
}
