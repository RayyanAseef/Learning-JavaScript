/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datatest;

import java.util.Scanner;

public class DataTest {

    public static boolean sixCharFun(String str) {
        
        int strLen = str.length();
        boolean check;
        
        if (strLen > 6) {
            check = true;
        }
        else {
            check = false;
        }
        
        return check;
        
    }
    
    public static boolean oneLowFun(String str) {
        
        int aFind = str.indexOf("a");
        boolean check;
        
        if (aFind != -1) {
            check = true;
        }
        else {
            check = false;
        }
        
        return check;
    }
    
    public static boolean noZFun(String str) {
        
        int strLen = str.length();
        int zFind = str.indexOf("z");
        int ZFind = str.indexOf("Z");
        boolean check;
        
        if (strLen >= 5 && strLen <= 15 && zFind == -1 && ZFind == -1) {
            check = true;
        }
        else {
            check = false;
        }
        
        return check;
                
    }
    
    public static boolean numBtwFun(int num) {
        
        boolean check;
        
        if (num >= 5 && num <= 500) {
            check = true;
        }
        else {
            check = false;
        }
        
        return check;
        
    }
    
    public static boolean negNumFun(int num) {
        
        boolean check;
        
        if (num < 0) {
            check = true;
        }
        else {
            check = false;
        }
        
        return check;
        
    }
    
    public static boolean posOddNumFun(int num) {
        
        boolean check;
        
        if (num > 0 && (num % 2) != 0) {
            check = true;
        }
        else {
            check = false;
        }
        
        return check;
        
    }
    
    public static void main(String[] args) {
        
        // Getting an input variable
        Scanner input = new Scanner(System.in); 
        
        // Declaring variable
        // Variables they input in
        String sixCharIn;
        String oneLowIn;
        String noZIn;
        String numBtwIn;
        String negNumIn;
        String posOddNumIn;
        
        int numBtwInNum;
        int negNumInNum;
        int posOddNumInNum;
        
        // Variables to check if they meet the requirements
        boolean sixCharCheck = false;
        boolean oneLowCheck = false;
        boolean noZCheck = false;
        boolean numBtwCheck = false;
        boolean negNumCheck = false;
        boolean posOddNumCheck = false;
        
        // Welcoming the user into the program
        System.out.println("Welcome to Data Testing Program!\n");
        
        // Telling the user what we want them to input
        System.out.println("Please Enter a string that is greator than six letters long:\n");
        
        // While loop until they entered what we want
        while (sixCharCheck == false) {
            // Getting them to input
            System.out.print("String: ");
            sixCharIn = input.next();
            
            // Using a function to see if what they entered is what we needed
            sixCharCheck = sixCharFun(sixCharIn);
        }
        
        // Telling the user what we want them to input
        System.out.println("\nPlease Enter a string with at least one lower case \"a\":\n");
        
        // While loop until they entered what we want
        while (oneLowCheck == false) {
            // Getting them to input
            System.out.print("String: ");
            oneLowIn = input.next();
            
            // Using a function to see if what they entered is what we needed
            oneLowCheck = oneLowFun(oneLowIn);
        }
        
        // Telling the user what we want them to input
        System.out.println("\nPlease Enter a string between 5 to 15 charactors and also doesnt have a \"z\" and \"Z\":\n");
        
        // While loop until they entered what we want
        while (noZCheck == false) {
            // Getting them to input
            System.out.print("String: ");
            noZIn = input.next();
            
            // Using a function to see if what they entered is what we needed
            noZCheck = noZFun(noZIn);
        }
        
        // Telling the user what we want them to input
        System.out.println("\nPlease Enter a number between 5 to 500:\n");
        
        // While loop until they entered what we want
        while (numBtwCheck == false) {
            // Getting them to input
            System.out.print("Number: ");
            numBtwIn = input.next();
            
            // Using try catch to make sure user enters a number
            try {
                // Convert the string the entered into a integer
                numBtwInNum = Integer.parseInt(numBtwIn);
                
                // Using a function to see if what they entered is what we needed
                numBtwCheck = numBtwFun(numBtwInNum);
            }
            catch (Exception e){
                // Telling them a error occured
                System.out.println("Error Occured Try Again");
            }
        }
        
        // Telling the user what we want them to input
        System.out.println("\nPlease Enter a negitive number:\n");
        
        // While loop until they entered what we want
        while (negNumCheck == false) {
            // Getting them to input
            System.out.print("Number: ");
            negNumIn = input.next();
            
            // Using try catch to make sure user enters a number
            try {
                // Convert the string the entered into a integer
                negNumInNum = Integer.parseInt(negNumIn);
                
                // Using a function to see if what they entered is what we needed
                negNumCheck = negNumFun(negNumInNum);
            }
            catch (Exception InputMismatchException){
                // Telling them a error occured
                System.out.println("Error Occured Try Again");
            }
        }
        
        // Telling the user what we want them to input
        System.out.println("\nPlease Enter a positive odd number:\n");
        
        // While loop until they entered what we want
        while (posOddNumCheck == false) {
            // Getting them to input
            System.out.print("Number: ");
            posOddNumIn = input.next();
            
            // Using try catch to make sure user enters a number
            try {
                // Convert the string the entered into a integer
                posOddNumInNum = Integer.parseInt(posOddNumIn);
                
                // Using a function to see if what they entered is what we needed
                posOddNumCheck = posOddNumFun(posOddNumInNum);
            }
            catch (Exception e){
                // Telling them a error occured
                System.out.println("Error Occured Try Again");
            }
        }
        
        // Telling farewell to the user
        System.out.println("\nThank You for Using this Program!");
        
    }
    
}
