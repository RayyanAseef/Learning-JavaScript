/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subroutinefunctions;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class SubroutineFunctions {
    
    // Making a method to find the Sphere's Volume
    public static void sphereVol() {
        
        // Decalring variables
        Scanner input = new Scanner(System.in);
        
        int radiusSphere;
        double vol;
        
        String unit;
        
        // Telling them what this option does
        System.out.println("To find the Sphere's Volume enter the information bellow:\n");
                
        // Getting them to fill in the required information
        System.out.print("Radius: ");
        radiusSphere = input.nextInt();

        System.out.print("Units: ");
        unit = input.next();
                
        // Getting the answer
        vol = (Math.pow(radiusSphere,3) * 3.14 * (4/3));
        
        // Rouning the sphere's volume
        vol = vol * 10;
        vol = Math.round(vol);
        vol = vol /10;
                
        // Displaying the answer to the user
        System.out.println("\nThe volume of the Sphere is " + vol + " " + unit + " cubed\n");
        
    }
    
    // Making a method to find the triangle perimeter
    public static void trianglePerimeter() {
        
        // Decalring varaibles
        Scanner input = new Scanner(System.in);
        
        int side1;
        int side2;
        int side3;
        int perimeter;
        
        String unit;
        
        // Telling them what this option does
        System.out.println("To find the perimeter of a triangle enter the information below:\n");
                
        // Getting them to fill in the required information
        System.out.print("Side 1: ");
        side1 = input.nextInt();
                
        System.out.print("Side 2: ");
        side2 = input.nextInt();
                
        System.out.print("Side 3: ");
        side3 = input.nextInt();
                
        System.out.print("Unit: ");
        unit = input.next();
                
        // Getting the perimeter
        perimeter = side1 + side2 + side3;
                
        // Displaying the answer to the user
        System.out.println("\nThe perimeter of the triangle is " + perimeter + " " + unit + "\n");
        
    }
    
    // Making a method to find how long the slope is
    public static void findSlope() {
        
        // Decalre Variables
        Scanner input = new Scanner(System.in);
        
        double point1x;
        double point1y;
        double point2x;
        double point2y;
        double slope;
        
        // Telling them what this option does
        System.out.println("To find the graphs lines length enter the information bellow:\n");
                
        // Getting them to fill in the required information
        System.out.print("Point one X: ");
        point1x = input.nextInt();
                
        System.out.print("point One Y: " );
        point1y = input.nextInt();
                
        System.out.print("point Two X: " );
        point2x = input.nextInt();
                
        System.out.print("point Two Y: " );
        point2y = input.nextInt();
        
        // Getting the slope
        slope = Math.sqrt(Math.pow((point2x - point1x),2) + Math.pow((point2y - point1y),2));
        
        // Rounding the slope
        slope = slope * 10;
        slope = Math.round(slope);
        slope = slope / 10;
        
        // Displaying the answer to the user
        System.out.println("\nThe Graphs lines length of the two points is " + slope + " units\n");
        
    } 
    
   // Making a method to find the rectangle's area
    public static void rectangleArea(){
        
        // Declaring variables
        Scanner input = new Scanner(System.in);
        
        double width;
        double length;
        double area;
        
        String unit;
        
        // Telling them what this option does
        System.out.println("To find the area of the rectangle enter the information bellow:\n");
                
        // Getting them to fill in the required information
        System.out.print("Width: ");
        width = input.nextInt();
                
        System.out.print("Length: ");
        length = input.nextInt();
                
        System.out.print("Units: ");
        unit = input.next();
                
        // Getting the area
        area = width * length;
                
        // Displaying the answer to the user
        System.out.println("\nThe area of the rectangle is " + area + " " + unit + " squared\n");
        
    }
    
    // Making a method to find the cubes surface area
    public static void cubeSurArea() {
        
        // Declaring Varaibles
        Scanner input = new Scanner(System.in);
        
        double sideLen;
        double surArea;
        
        String unit;
        
        // Telling them what this option does
        System.out.println("To find the Surface Area of the cube enter the information bellow:\n");
                
        // Getting them to fill in the required information
        System.out.print("Side length: ");
        sideLen = input.nextInt();
                
        System.out.print("Units: ");
        unit = input.next();
                
        // Using the method cubeSurArea and returning the answer to the variable surArea
        surArea = 6 * (Math.pow(sideLen,2));
                
        // Displaying the answer to the user
        System.out.println("\nThe Surface Area is " + surArea + " " + unit + " squared\n");
        
    }
    
    // The main method
    public static void main(String[] args) {
        
        // Declaring variables
        Scanner input = new Scanner(System.in);
        
        int choice = 0;
        
        // Telling them what the name of the product is 
        System.out.println("Welcome to the Math Machine");
        
        // Starting a while loop for the menu untill they want exit
        while (choice != 6) {
            // Showing them the menu
            System.out.println("From the menu bellow choose which fuction you want to use: \n");
            System.out.println("1 = Finding the Volume of a Sphere");
            System.out.println("2 = Finding the Perimeter of a Triangle");
            System.out.println("3 = Finding the Graphs Lines Length");
            System.out.println("4 = Finding the Area of a Rectangle");
            System.out.println("5 = Finding the Surface Area of a Cube");
            System.out.println("6 = Exit\n");
            
            // Telling them to pick one of the menu
            System.out.print("Pick: ");
            choice = input.nextInt();
            
            //Telling them what they picked
            System.out.println("\nYou picked " + choice + (":\n"));
            
            // If they pick 1
            if (choice == 1) {
                sphereVol();
            }
            
            // If they pick 2
            if (choice == 2) {
                trianglePerimeter();
            }
            
            // If they pick 3
            if (choice == 3) {
                findSlope();
            }
            
            // If they pick 4
            if (choice == 4) {
                rectangleArea();
            }
            
            // If they pick 5
            if (choice == 5) {
                cubeSurArea();
            }
            
            // If they pick 6
            if (choice == 6) {
                // Telling them what this option does
                System.out.println("Thank you for using the Math Machine.");
                
                // Exiting the while loop
                break;
            }
            
            // If they pick a number above 6
            if (choice > 6 ) {
                // Telling them the number they picked is invalid
                System.out.println("INVALID NUMBER TRY AGAIN\n");
            }
            
        }

    }
    
}
