
// Importing JFrame
import javax.swing.JFrame;

public class Window extends JFrame{
    
    // Making a Main Subroutine 
    public static void mainProgram() {
        
        // Using Subroutine showWindow
        showWindow();
        
    }
    
    // Making Subroutine showWindow to display the window 
    public static void showWindow() {
        // Making a JFrame Instince 
        JFrame frame = new JFrame("Window");
        
        // Setting Jframe bounderies and making it visible 
        frame.setBounds(100,100,100,100);
        frame.setVisible(true);
        
        // making the whole program close when the close button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
}
