
package pkgclass.practice;

public class ClassPractice {

    public static void main(String[] args) {
        
        Window screen = new Window();
        
    }
    
}
