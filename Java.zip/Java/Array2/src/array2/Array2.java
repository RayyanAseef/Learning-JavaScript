/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array2;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Array2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Making an input variable
        Scanner keyedInput = new Scanner(System.in);
        
        // Decalaring the variable
        String [] friends = new String[10];
        
        // Telling the user to enter 5 of their friends name
        System.out.println("Enter 5 of your friends names bellow:\n");
        
        // Getting the users 5 friends name
        for (int i = 0;i <= 4;i = i + 1) {
            System.out.print("Friend " + (i + 1) + ": ");
            friends[i] = keyedInput.nextLine();
        }
        
        // Showing the user the second, third and forth name of their friends they entered
        System.out.println("\nYour Second friend is " + friends[1]);
        System.out.println("Your Third friend is " + friends[2]);
        System.out.println("Your Fourth friend is " + friends[3]);
        
    }
    
}
