/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aboutmeaseef;

/**
 *
 * @author S300062235
 */
public class AboutMeAseef {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("My name is Rayyan.");
        System.out.println("I live in 36 Geddy st.");
        System.out.println("I took graded 10 computer science"
                + "and I had fun so, I decided to continue in Grade 11.");
        System.out.println("I hope to learn how to program in Java.");
        System.out.println("My favourite technology is my smartphone "
                + "iPhone X.");
        System.out.println("My favourite app is youtube because I like"
                + "watching videos in my free time.");
        System.out.println("I am good at math,sciemce and computer science");
    }
    
}
