/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package textadventure;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class TextAdventure {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Importing Scanner in the varaible keyedinput
        Scanner keyedInput = new Scanner(System.in);
        
        // Naming my variables
        String ansOne;
        String ansTwo;
        String ansThree;
        String ansFour;
        String ansFive;
        String ansSix;
        String ansSeven;
        String ansEight;
        String ansNine;
        String ansTen;
        
        // Intro to the hanted House telling them they have two hallways infront of them and they are picking one
        System.out.println("Welcome to the Haunted House\n");
        System.out.println("You have two hallways in front of you");
        System.out.println("Do you want to enter the one on the left or the one on the right");
        System.out.println("Type either \"Right\" to go to the right hallway or \"Left\" to go to the left hallway\n");
        
        System.out.print("Decision: ");
        ansOne = keyedInput.nextLine();
        ansOne = ansOne.toLowerCase();
        
        if (ansOne.equals("right")) {
            // Teloing them the entered a dead end and got locked in so they die of startvation
            System.out.println("\nYou go further in the Right hallway just to find a dead end "
                    + "and even worse you have been locked in side here\n");
            System.out.println("You died of Starvation!");
        }
        
        else if (ansOne.equals("left")) {
            // Telling them the  door and windows keep opening so do they want to leave or hide
            System.out.println("\nAs you go further in the second hallway, you enter a room and inside the doors and windows"
                    + " keep opening and closing\n");
            System.out.println("Do you want to leave or hide");
            System.out.println("Type either \"Leave\" to leave the room or \"Hide\" to hide in the room\n");
            
            System.out.print("Decision: ");
            ansTwo = keyedInput.nextLine();
            ansTwo = ansTwo.toLowerCase();
            
            if (ansTwo.equals("hide")) {
                System.out.println("\nYou just hid behind the table");
                System.out.println("All the doors and windows have been locked\n");
                System.out.println("Do you want to break the door or the window");
                System.out.println("Type either \"Break Door\" to break the door or \"Break Window\" to break the window\n");
                
                System.out.print("Decision: ");
                ansThree = keyedInput.nextLine();
                ansThree = ansThree.toLowerCase();
                
                if (ansThree.equals("break door")) {
                    System.out.println("\nYou just broke the door and things came flying at you!\n");
                    System.out.println("You just died!");
                }
                else if (ansThree.equals("break window")) {
                    System.out.println("\nYou just broke the window, you look down and see you are really high up\n");
                    System.out.println("Do you want to jump or break the door");
                    System.out.println("Type either \"Break Door\" to break the door or \"Jump\" to jump from the window\n");
                    
                    System.out.print("Decision: ");
                    ansFour = keyedInput.nextLine();
                    ansFour = ansFour.toLowerCase();
                    
                    if (ansFour.equals("break door")) {
                        System.out.println("\nThings just came flying at you!\n");
                        System.out.println("You just died!");
                    }
                    else if (ansFour.equals("jump")) {
                        System.out.println("\nYou just broke a couple of bones, but you survived!\n");
                        System.out.println("Congratulations you won!");
                    }
                }
            }
            else if (ansTwo.equals("leave")) {
                System.out.println("\nYou just left the room and all of a sudden all the lights just closed\n");
                System.out.println("Do you want to continue forward or stay near the floor");
                System.out.println("Type either \"Forward\" to continue forward or \"Floor\" to stay down near the floor\n");
                
                System.out.print("Decision: ");
                ansThree = keyedInput.nextLine();
                ansThree = ansThree.toLowerCase();
                
                if (ansThree.equals("forward")) {
                    System.out.println("\nAs you continue to move forward things come flying at you!\n");
                    System.out.println("You just died!");
                }
                else if (ansThree.equals("floor")) {
                    System.out.println("\nDo you want to crawl forward or stay where you are until the lights open");
                    System.out.println("Type either \"Light Open\" to wait for the lights to open or \"Forward\" to crawl forward\n");
                    
                    System.out.print("Decision: ");
                    ansFour = keyedInput.nextLine();
                    ansFour = ansFour.toLowerCase();
                    
                    if (ansFour.equals("light open")) {
                        System.out.println("You wait for the lights to open, but before that the chandelier above you falls on you\n");
                        System.out.println("You died!");
                    }
                    else if (ansFour.equals("forward")) {
                        System.out.println("\nAs you crawl forward there is a room in front of you\n");
                        System.out.println("Do you want to enter or do you want to continue to go further in the hallway");
                        System.out.println("Type either \"Enter\" to enter the room or \"Forward\" to continue walking forward in the hallway\n");
                        
                        System.out.print("Decision: ");
                        ansFive = keyedInput.nextLine();
                        ansFive = ansFive.toLowerCase();
                        
                        if (ansFive.equals("enter")) {
                            System.out.println("\nYou enter the room and the doors lock behind you(You see a fireplace)");
                            System.out.println("Do you break the door or climb the fireplace");
                            System.out.println("Type either \"Break Door\" to break the door or \"climb\" to climb the fireplace\n");
                            
                            System.out.print("Decision: ");
                            ansSix = keyedInput.nextLine();
                            ansSix = ansSix.toLowerCase();
                            
                            if (ansSix.equals("break door")) {
                                System.out.println("\nYou break the door,but things come fling at you!\n");
                                System.out.println("You died!");
                            }
                            else if (ansSix.equals("climb")) {
                                System.out.println("\nYou climb out of the house and people see you, so they call help to get you of the house\n");
                                System.out.println("You escaped!");
                            }
                        }
                        else if (ansFive.equals("forward")) {
                            System.out.println("\nYou continue to crawl forward in the hallway and find a couple of wood sticks on the floor\n");
                            System.out.println("Do you make a torch with the sticks or continue moving forward");
                            System.out.println("Type either \"Forward\" to continue forward or \"Torch\" to make a torch\n");
                            
                            System.out.print("Decision: ");
                            ansSix = keyedInput.nextLine();
                            ansSix = ansSix.toLowerCase();
                            
                            if (ansSix.equals("forward")) {
                                System.out.println("\nYou wander aimlessly for a couple of hours until you lose hope!\n");
                                System.out.println("You died of starvation!");
                            }
                            else if (ansSix.equals("torch")) {
                                System.out.println("\nYou made a torch and move forward and then find a staircase\n");
                                System.out.println("Do you hold railing while going down or do you go down with out holding the railing or stay up");
                                System.out.println("Type either \"No Hold\" to not hold the railing or \"Hold\" to hold the railing or \"Stay Up\" to stay upstairs\n");
                                
                                System.out.print("Decision: ");
                                ansSeven = keyedInput.nextLine();
                                ansSeven = ansSeven.toLowerCase();
                                
                                if (ansSeven.equals("no hold")) {
                                    System.out.println("\nThe stairs break underneath you and you die!");
                                }
                                else if (ansSeven.equals("stay up")) {
                                    System.out.println("\nYou droped the torch and the house burned and collapsed on you!\n");
                                    System.out.println("You Died!");
                                }
                                else if (ansSeven.equals("hold")) {
                                    System.out.println("\nYou are holdig the raling while you go on the staircase, but the stairs break underneath you so you are hanging on the railing\n");
                                    System.out.println("Do you climb back up or continue clibing down");
                                    System.out.println("Type either \"Go Up\" to go up or \"Go Down\" to go down\n");
                                    
                                    System.out.print("Decision: ");
                                    ansEight = keyedInput.nextLine();
                                    ansEight = ansEight.toLowerCase();
                                    
                                    if (ansEight.equals("go up")) {
                                        System.out.println("\nYou go back up succesfully, but that was you only hope to survive\n");
                                        System.out.println("You die of starvation!");
                                    }
                                    else if (ansEight.equals("go down")) {
                                        System.out.println("\nYou feel like the raling is about to break\n");
                                        System.out.println("Do you Continue going down or jump or go back up");
                                        System.out.println("Type either \"Go Down\" to go down holding the raling or \"Go Up\" to go back up or \"Jump\" to jump\n");
                                        
                                        System.out.print("Decision: ");
                                        ansNine = keyedInput.nextLine();
                                        ansNine = ansNine.toLowerCase();
                                        
                                        if (ansNine.equals("go down")) {
                                            System.out.println("\nThe raling breaks and the house collapse on you\n");
                                            System.out.println("You died!");
                                        }
                                        else if (ansNine.equals("go up")) {
                                            System.out.println("\nThe raling breaks and the house collapse on you\n");
                                            System.out.println("You died!");
                                        }
                                        else if (ansNine.equals("jump")) {
                                            System.out.println("\nYou survived the jump and they are two doors in front of you\n");
                                            System.out.println("Do you open the left door or the right door");
                                            System.out.println("Type either \"Right\" to go to the right house or the \"Left\" to go to the left house\n");
                                            
                                            System.out.print("Decision: ");
                                            ansTen = keyedInput.nextLine();
                                            ansTen = ansTen.toLowerCase();
                                            
                                            if (ansTen.equals("left")) {
                                                System.out.println("\nThings come flying at you\n");
                                                System.out.println("You died!");
                                            }
                                            else if (ansTen.equals("right")) {
                                                System.out.println("\nYou have succesfully escaped!");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
}
