/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class algorithJframe extends javax.swing.JFrame {
    
    // Making a method to find the factoroil number of the number the use enters
    public static int factorialFind(int facNum) {
        
        // Decalring variables
        int ans = 1;
        
        // Using a for loop to find the factorial answer
        for (int i = 1;i <= facNum;i = i + 1) {
            // Multiplying the number with i every loop to get teh factorial answer
            ans = ans * i;
        }
        
        // returning the answer
        return ans;
        
    }
    
    // Making a methods to check if the number the user enters is  a prime numbers
    public static boolean primeCheck(int priNum) {
        
        // Decalring variables
        boolean check = true;
        double priAns;
        
        // Using a for loop to check if teh number they entered is a prime number by checking every posibility
        for (int i = 2; i <= priNum/2;++i) {
            // Checking is the number is not prime
            if (priNum % i == 0) {
                // If it isn't prime the answer is false
                check = false;
                // break the loop
                break;
            }
        }
        
        // returning the answer
        return check;
        
    }
    
    // This method is to find what the fibonacci number is of that place the user enters
    public static int fibonFind(int fibonNum) {
        
        // Decalring variables
        int ans = 1;
        int prevAnsI = 0;
        int prevAnsII = 0;
        int sum;
        
        // Using a for loop to check what the fibonacci number of the place teh user wats to find out is
        for (int i = 1; i <= fibonNum; ++i) {
            
            // Getting the sum of the previous two numbers
            sum = ans + prevAnsI;
            
            // The fabonacci number in the place 2 time back then were the for loop is
            prevAnsII = prevAnsI;
            // The fabonacci number in the place 1 time back then were the for loop is
            prevAnsI = ans;
            // The fabonacci number of where the for loop is
            ans = sum;
            
        }
        
        // returning the answer
        return prevAnsII;
        
    }
    
    public algorithJframe() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        factorialNum = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        factorialAns = new javax.swing.JLabel();
        primeNum = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        primeAns = new javax.swing.JLabel();
        fibonacciNum = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        fibonacciAns = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("--Numbers--");

        jLabel2.setText("Enter a number and click the button to find the factorial:");

        jButton1.setText("Factorial");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        factorialAns.setText("unknown");

        jButton2.setText("Prime");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        primeAns.setText("unknown");

        jButton3.setText("Fibonacci");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        fibonacciAns.setText("unknown");

        jLabel3.setText("Enter a number a press the button to determine whether or not it is a prime number:");

        jLabel4.setText("Enter a number and click the button to see the corresponding Fibonacci number:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(fibonacciNum, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                            .addComponent(primeNum)
                            .addComponent(factorialNum))
                        .addGap(99, 99, 99)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3)
                            .addComponent(jButton1)
                            .addComponent(jButton2))
                        .addGap(82, 82, 82)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(primeAns)
                            .addComponent(factorialAns)
                            .addComponent(fibonacciAns)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(factorialNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(factorialAns))
                .addGap(29, 29, 29)
                .addComponent(jLabel3)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(primeNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2)
                    .addComponent(primeAns))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fibonacciNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3)
                    .addComponent(fibonacciAns))
                .addGap(80, 80, 80))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        // Decalring variables
        int facNum;
        int ans;
        
        // Getting the number the user wants to get the factorial for
        facNum = Integer.parseInt(factorialNum.getText());
        
        // Using the method to get the answer inside the variable
        ans = factorialFind(facNum);
        
        // Telling the user the answer
        factorialAns.setText(String.valueOf(ans));
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        // Decalring variables
        int priNum;
        boolean ans;
        
        // Getting the number the user want to check if it is prime
        priNum = Integer.parseInt(primeNum.getText());
        
        // Using the method to get the answer inside the variable
        ans = primeCheck(priNum);
        
        // Telling the user the answer
        primeAns.setText(String.valueOf(ans));
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        // Decalring variables
        int fibonNum;
        int fibonAns;
        
        // Getting the place the user wants to see the fibonacci number 
        fibonNum = Integer.parseInt(fibonacciNum.getText());
        
        // Using the method to get the answer inside the variable
        fibonAns = fibonFind(fibonNum);
        
        // Telling the user the answer
        fibonacciAns.setText(String.valueOf(fibonAns));
        
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(algorithJframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(algorithJframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(algorithJframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(algorithJframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new algorithJframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel factorialAns;
    private javax.swing.JTextField factorialNum;
    private javax.swing.JLabel fibonacciAns;
    private javax.swing.JTextField fibonacciNum;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel primeAns;
    private javax.swing.JTextField primeNum;
    // End of variables declaration//GEN-END:variables
}
