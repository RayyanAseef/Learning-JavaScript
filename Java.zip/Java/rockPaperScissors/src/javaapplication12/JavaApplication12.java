/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication12;

import java.util.Scanner;

/**
 *
 * @author s300062235
 */
public class JavaApplication12 {
    
    // Making a method for the menu
    public static void menu(String str1,String str2, String str3,String str4) {
        // Decalring variable
        String [] menu = {str1,str2,str3,str4};
        
        // Using a for loop to show the menu
        for (int i = 0;i < 4;i = i + 1) {
            System.out.println(menu[i]);
        }
        
    }
    
    // Making a method to show the win lose tie satistics
    public static void winLoseTieDisplay(int w, int l, int t) {
        // Decalring variables
        String [] winLoseTieStr = {"\nWin: ","Lose: ","Tie: "};
        int [] winLoseTieInt = {w,l,t};
        
        // Using the for loop to show the satistics
        for (int i = 0;i < 3; i = i + 1) {
            System.out.print(winLoseTieStr[i]);
            System.out.println(winLoseTieInt[i]);
        }
        
    }
    
    // Making a method to show the satistics of what they picked in their games
    public static void pickDisplay(int rPick,int pPick, int sPick, int r) {
        // Decalring variable
        String [] pickCalStr = {"\nRock Picked: ","Paper Picked: ","Scissor Picked: ","\nRounds Played: "};
        int [] pickCal = {rPick,pPick,sPick,r};
        
        // Using a for loop to show the satistics
        for (int i = 0;i < 4; i = i + 1) {
            System.out.print(pickCalStr[i]);
            System.out.println(pickCal[i]);
        }
        
        // Making a space
        System.out.println("\n");
        
    }
    
    // This is the main method
    public static void main(String[] args) {
        
        // Getting an input variable
        Scanner input = new Scanner(System.in);    
        
        // Decalring variables
        int ranNum = 0;
        int pick = 0;
        int round = 0;
        int option = 0;
        int done = 0;
        
        int win = 0;
        int lose = 0;
        int tie = 0;
        
        int rockPick = 0;
        int paperPick = 0;
        int scissorPick = 0;
        
        // Welcoming the user
        System.out.println("Welcome to the Rock Paper Scissors Game\n");
        
        // Telling them what type of rock paper scissors match they want to do
        System.out.println("How would you like your match:\n");
        
        // Showing them their menu to pick from
        menu("1 = First to 3 Wins, Wins the Match","2 = First to 5 Wins, Wins the Match","3 = First to 7 Wins, Wins the Match","4 = As Much as you like\n");
        
        // Getting them to pick what they want
        System.out.print("Option: ");
        option = input.nextInt();
        
        // if they pick 1 making the while loop close when the first person to get 3 wins, wins
        if (option == 1) {
            System.out.println("\nYou Picked First to 3");
            done = 3;
        }
        
        // if they pick 2 making the while loop close when the first person to get 5 wins, wins
        if (option == 2) {
            System.out.println("\nYou Picked First to 5");
            done = 5;
        }
        
        // if they pick 3 making the while loop close when the first person to get 7 wins, wins
        if (option == 3) {
            System.out.println("\nYou Picked First to 7");
            done = 7;
        }
        
        // If they pick 4 they can play until they feel like it
        if (option == 4) {
            System.out.println("\nYou Picked 4 to Play as Much as You Want");
            done = -1;
        }
        
        while (pick != 4 && win != done && lose != done) {
            if (round == 0) {
                System.out.println("\n-----------------------------");    
            }
            
            // Telling them to pick if they want to pick rock,paper,scissors or quit
            System.out.println("\nPick one of the Options Bellow:\n");
            menu("1 = Rock","2 = Paper","3 = Scissor","4 = Exit\n");
            
            // Getting what they picked
            System.out.print("Pick: ");
            pick = input.nextInt();
            
            // Getting a random number from 3 to decide if the computer picked rock, paper or scissors
            ranNum = (int)Math.round(Math.random()*2 + 1);
            
            // An if statement for when they pick 1 or in other words rock
            if (pick == 1) {
                // Telling them they picked rock
                System.out.println("\nYou Picked Rock");
                // Adding 1 to how many times they picked rock
                rockPick = rockPick + 1;
                
                // If the random pick was 1 or in other words rock
                if (ranNum == 1) {
                    // Telling them the computer picked rock
                    System.out.println("The Computer Picked Rock!");
                    // Telling them it is a tie
                    System.out.println("It is a tie");
                    
                    // Adding 1 to the tie variable
                    tie = tie + 1;
                }
                
                // If the random pick was 2 or in other words paper
                if (ranNum == 2) {
                    // Telling them the computer picked paper
                    System.out.println("The Computer Picked Paper!");
                    // Telling them they lost
                    System.out.println("You lost");
                    
                    // Adding 1 to the lose variable
                    lose = lose + 1;
                }
                
                // If the random pick was 3 or in other words scissor
                if (ranNum == 3) {
                    // Telling them the computer picked scissors
                    System.out.println("The Computer Picked Scissors!");
                    // Telling them they won
                    System.out.println("You Won");
                    
                    // Adding 1 to the win variable
                    win = win + 1;
                }
            }
            
            // An if statement for when they pick 2 or in other words paper
            if (pick == 2) {
                // Telling them they picked paper
                System.out.println("\nYou Picked Paper");
                // Adding 1 to how many times they picked paper
                paperPick = paperPick + 1;
                
                // If the random pick was 1 or in other words rock
                if (ranNum == 1) {
                    // Telling them the computer picked rock
                    System.out.println("The Computer Picked Rock!");
                    // Telling them they won
                    System.out.println("You Won");
                    
                    // Adding 1 to the win variable
                    win = win + 1;
                }
                
                // If the random pick was 1 or in other words paper
                if (ranNum == 2) {
                    // Telling them the computer picked paper
                    System.out.println("The Computer Picked Paper!");
                    // Telling them it is a tie
                    System.out.println("It is a Tie");
                    
                    // Adding 1 to the tie variable
                    tie = tie + 1;
                }
                
                // If the random pick was 1 or in other words scissor
                if (ranNum == 3) {
                    // Telling them the computer picked scissors
                    System.out.println("The Computer Picked Scissors!");
                    // Telling them they lost
                    System.out.println("You Lost");
                    
                    // Adding 1 to the lose variable
                    lose = lose + 1;
                }
            }
            
            // An if statement for when they pick 3 or in other words scissors
            if (pick == 3) {
                // Telling them they picked scissors
                System.out.println("\nYou Picked Scissors");
                // Adding 1 to how many times they picked scissors
                scissorPick = scissorPick + 1;
                
                // If the random pick was 1 or in other words rock
                if (ranNum == 1) {
                    // Telling them the computer picked rock
                    System.out.println("The Computer Picked Rock!");
                    // Telling them they lost
                    System.out.println("You lost");
                    
                    // Adding 1 to the lose variable
                    lose = lose + 1;
                }
                
                // If the random pick was 1 or in other words paper
                if (ranNum == 2) {
                    // Telling them the computer picked paper
                    System.out.println("The Computer Picked Paper!");
                    // Telling them they won
                    System.out.println("You Won");
                    
                    // Adding 1 to the win variable
                    win = win + 1;
                }
                
                // If the random pick was 1 or in other words scissor
                if (ranNum == 3) {
                    // Telling them the computer picked scissors
                    System.out.println("The Computer Picked Scissors!");
                    // Telling them it is a tie
                    System.out.println("It is a tie");
                    
                    // Adding 1 to the tie variable
                    tie = tie + 1;
                }
            }
            
            // An if statement foer when pick isnt 4 and win or lose isnt equal to done 
            // and their pick isnt more than 4 and less than 1 
            if (pick != 4 && win != done && lose != done && pick <= 4 && pick >= 1) {
                // Addin one to the round variable
                round = round + 1;
                // Showing the win lose tie satistics
                winLoseTieDisplay(win,lose,tie);
                
                System.out.println("\n-----------------------------");
            }
            
            // if their pick is bigger than 4 and less than one 
            if (pick > 4 || pick < 1) {
                // Telling them their number is invalid
                System.out.println("INVALID NUMBER");
            }
        }
        
        // If they didnt pick to play until they feel like it
        if (option != 4) {
            // if they have more wins then loses and they didnt quit
            if (win > lose && pick != 4) {
                // Telling them they won
                System.out.println("\nYOU WIN THE MATCH");
                // Adding 1 to rounds
                round = round + 1;
            }
            // if they have more loses then wins and they didnt quit
            else if (win < lose && pick != 4) {
                // Telling them they lost the match
                System.out.println("\nYOU LOSE THE MATCH");
                // Adding 1 to rounds
                round = round + 1;
            }
            // Anything else (Mainly if they quit) (I dont think their is an other way to this if stement instead of quiting)
            else {
                // Telling them they lost
                System.out.println("\nYOU LOSE THE MATCH");
            }
        }
        
        // Telling them their win lose tie satistics
        winLoseTieDisplay(win,lose,tie);
        // Telling them their satistics for what they picked
        pickDisplay(rockPick,paperPick,scissorPick,round);
        
        
        // Giving them their farewell message
        System.out.println("Thank you for playing Rock Paper and Scissors in this Program");
        System.out.println("\n-----------------------------");
        
    }
    
}
