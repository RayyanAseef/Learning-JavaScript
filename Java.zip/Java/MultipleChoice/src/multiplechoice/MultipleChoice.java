/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplechoice;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class MultipleChoice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Making an input variable
        Scanner keyedInput = new Scanner(System.in);
        
        // Decalring user input variables
        String answerOne;
        String answerTwo;
        String answerThree;
        String answerFour;
        String answerFive;
        
        // Making arrays for the multiple choice
        String [] loopOne = {"June 1st", "March 1st", "July 1st", "Januvary 1st"};
        int [] loopTwo = {151, 152, 153, 154};
        String [] loopThree = {"British Columbia", "Yukon", "Prince Edward Island", "Saskatchewan"};
        String [] loopFour = {"Paul Martin", "Justin Trudeau", "Stephen Harper", "Alexander Mackenzie"};
        String [] loopFive = {"Largest", "Second Largest", "Third Largest", "Four Largest"};
        
        // Making score and percentage variabels
        int score = 0;
        double percScore;
        
        // Starting text to user telling them what quiz this is
        System.out.println("Welcome to the Canada Quiz.\n");
        // Displaying question one
        System.out.println("Question 1: When is Canada Day? \n");
        
        // Displaying question one multiple choice options
        for (int i = 0;i <=3;i = i + 1) {
            System.out.print((i + 1) + "." );
            System.out.println(loopOne[i]);
        }
        
        // Having them input what they thnk is the answer
        System.out.print("\nAnswer: ");
        answerOne = keyedInput.nextLine();
        answerOne = answerOne.toLowerCase();
        
        // Checking if there answer is correct
        if (answerOne.equals("july 1st") || answerOne.equals("3")) {
            // If correct display this
            System.out.println("You are Correct!!\n");
            score = score + 1;
        }
        else {
            // If wrong display this
            System.out.println("Sorry\n");
        }
        // Displaying question two
        System.out.println("Question 2: How old is Canada? \n");
        
        // Displaying question two multiple choice options
        for (int i = 0;i <=3;i = i + 1) {
            System.out.print((i + 1) + "." );
            System.out.println(loopTwo[i]);
        }
        
        // Having them input what they thnk is the answer
        System.out.print("\nAnswer: ");
        answerTwo = keyedInput.nextLine();
        
        // Checking if there answer is correct
        if (answerTwo.equals("153") || answerTwo.equals("3")) {
            // If correct display this
            System.out.println("You are Correct!!\n");
            score = score + 1;
        }
        else {
            // If wrong display this
            System.out.println("Sorry\n");
        }
        // Displaying question three
        System.out.println("Question 3:Which one is a Territory\n");
        
        // Displaying question three multiple choice options
        for (int i = 0;i <=3;i = i + 1) {
            System.out.print((i + 1) + "." );
            System.out.println(loopThree[i]);
        }
        
        // Having them input what they thnk is the answer
        System.out.print("\nAnswer: ");
        answerThree = keyedInput.nextLine();
        answerThree = answerThree.toLowerCase();
        
        // Checking if there answer is correct
        if (answerThree.equals("yukon") || answerThree.equals("2")) {
            // If correct display this
            System.out.println("You are Correct!!\n");
            score = score + 1;
        }
        else {
            // If wrong display this
            System.out.println("Sorry\n");
        }
        // Displaying question four
        System.out.println("Question 4:What is our current president?\n"); 
       
        // Displaying question four multiple choice options
        for (int i = 0;i <=3;i = i + 1) {
            System.out.print((i + 1) + "." );
            System.out.println(loopFour[i]);
        }
        
        // Having them input what they thnk is the answer
        System.out.print("\nAnswer: ");
        answerFour = keyedInput.nextLine();
        answerFour = answerFour.toLowerCase();
        
        // Checking if there answer is correct
        if (answerFour.equals("justin trudeau") || answerFour.equals("2")) {
            // If correct display this
            System.out.println("You are Correct!!\n");
            score = score + 1;
        }
        else {
            // If wrong display this
            System.out.println("Sorry\n");
        }
        // Displaying question five
        System.out.println("Question 5:What place is Canada in the lagest countries\n");
        
        // Displaying question five multiple choice options
        for (int i = 0;i <=3;i = i + 1) {
            System.out.print((i + 1) + "." );
            System.out.println(loopFive[i]);
        }
        
        // Having them input what they thnk is the answer
        System.out.print("\nAnswer: ");
        answerFive = keyedInput.nextLine();
        answerFive = answerFive.toLowerCase();
        
        // Checking if there answer is correct
        if (answerFive.equals("second largest") || answerFive.equals("2")) {
            // If correct display this
            System.out.println("You are Correct!!\n");
            score = score + 1;
        }
        else {
            // If wrong display this
            System.out.println("Sorry\n");
        }
        
        // Getting the right percentage
        percScore = (score / 5.0) * 1000;
        percScore = Math.round(percScore);
        percScore = percScore / 10;
        
        // Displaying how much they got right, how much they got wrong and the percentage of what they got right
        System.out.println("You answered " + score + " questions correct.");
        System.out.println("You answered " + (5 - score) + " questions incorrect.");
        System.out.println("You answered " + percScore + "% of questions correct.");
        
    }
    
}
