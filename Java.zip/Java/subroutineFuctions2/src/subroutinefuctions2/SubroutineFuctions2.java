/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package subroutinefuctions2;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class SubroutineFuctions2 {
    
    // Making a method to show the menu
    public static void menu() {
        
    System.out.println("From the menu bellow choose which fuction you want to use: \n");
    System.out.println("1 = Finding the Volume of a Sphere");
    System.out.println("2 = Finding the Perimeter of a Triangle");
    System.out.println("3 = Finding the Graphs lines Length");
    System.out.println("4 = Finding the Area of a Rectangle");
    System.out.println("5 = Finding the Surface Area of a Cube");
    System.out.println("6 = Finding the Volume of a Rectangle Prism");
    System.out.println("7 = Finding the Perimeter of a Pentagon");
    System.out.println("8 = Finding the Area of the Triangle");
    System.out.println("9 = Finding the Surface Area of the Square Based Triangular Pyrimid");
    System.out.println("10 = Finding the Surface Area of a Cylander");
    System.out.println("11 = Exit\n");
        
    }
    
    // Making a method to find the sphere's volume
    public static double sphereVol(double radius) {

        // Decalring a variable
        double ans;
        
        // using the information entered in the method finding the volume of the spher
        ans = (Math.pow(radius,3) * 3.14 * (4/3));
        
        // Rounding the answer
        ans = ans * 10;
        ans = Math.round(ans);
        ans = ans /10;
        
        // Returning the sphere's volume
        return ans;
        
    }
    
    // Making a method to find the triangle perimeter
    public static double trianglePerimeter(double s1,double s2,double s3) {
        
        // Decalring a variable and using the information entered in the method getting the perimeter of the triangle
        double perimeter = s1 + s2 + s3;
        
        // Returing the perimeter of the triangle
        return perimeter;
        
    }
    
    // Making a method to find how long the slope is
    public static double graphLineLen(double P1x,double P1y,double P2x,double P2y) {
        
        // Decalring a variable and using the information entered in the method getting the slope
        double slope = (P2y - P1y) / (P2x - P1x);
        
        // Rounding the slope
        slope = slope * 10;
        slope = Math.round(slope);
        slope = slope / 10;
        
        // Retuning the slope
        return slope;
    } 
    
   // Making a method to find the rectangle's area
    public static double rectangleArea(double wid,double len){
        
        // Decalring a variable and using the information entered in the method getting the area of the rectangle
        double areaRec = wid * len;
        
        // Returning the area of the rectangle
        return areaRec;
        
    }
    
    // Making a method to find the cubes surface area
    public static double cubeSurArea(double sideLen) {
        
        // Decalring a variable and using the information entered in the method getting the Surface Area of the cube
        double surfArea = 6 * Math.pow(sideLen,2);
        
        // returing the surface area of the cube
        return surfArea;
        
    }
    
    // Making a method to find the rectangular prisms volume
    public static double recVol(double len,double wid,double height) {
        
        double vol = len * wid * height;
        
        return vol;
        
    }
    
    // Making a method to find the perimeter pentagon
    public static double perimeterPentagon(double s1,double s2, double s3,double s4,double s5) {
        
        double perimeter = s1 + s2 + s3 + s4 + s5;
        
        return (perimeter);
        
    }
    
    // Making a method to find the triangulars area
    public static double triArea(double b,double h) {
        
        double area = (b * h) / 2;
        
        area = area * 10;
        area = Math.round(area);
        area = area / 10;
        
        return area;
        
    }
    
    // Making a method to find the surface area of the square based triangular pyrimid
    public static double triPyrSurArea(double sideLen, double triHeight) {
        
        double surArea = (sideLen * sideLen) + 4  * ((sideLen * triHeight) / 2);
        
        surArea = surArea * 10;
        surArea = Math.round(surArea);
        surArea = surArea / 10;
        
        return surArea;
        
    }
    
    // Making a method to find the surface area of the cylinder
    public static double cylSurArea(double radius,double height) {
        
        double surArea = (2 * 3.14 * radius * height) + (2 * 3.14 * Math.pow(radius,2));
        
        surArea = surArea * 10;
        surArea = Math.round(surArea);
        surArea = surArea / 10;
        
        return surArea;
        
    }
    
    // The main method
    public static void main(String[] args) {
        
        // Declaring variables
        Scanner input = new Scanner(System.in);
        
        // Varaible to check the option they pick
        int choice = 0;
        
        // Varaibles for choice 1
        double radiusSphere;
        double vol;
        
        // Varaibles for choice 2
        double [] sidesTri = new double[3];
        double perimeterTri;
        
        // Varaibles for choice 3
        double point1x;
        double point1y;
        double point2x;
        double point2y;
        double graphLine;
        
        // Varaibles for choice 4
        double widthRecArea;
        double lengthRecArea;
        double area;
        
        // Varaibles for choice 5
        double sideLen;
        double surArea;
        
        // Varaibles for choice 6
        double lengthRecVol;
        double widthRecVol;
        double heightRecVol;
        double recVolAns;
        
        // Varaibles for choice 7
        double [] sidesPen = new double[5];
        double perimeterPen;
        
        // Varaibles for choice 8
        double baseTri;
        double heightTri;
        double triAreaAns;
        
        // Variables for choice 9
        double sqSideLen;
        double pyrHeight;
        double surAreaPyr;
        
        // Varaibles for choice 10
        double radiusCylinder;
        double heightCylinder;
        double surAreaCylinder;
        
        // Varaibles for all choices but 3
        String unit;
        
        // Telling them what the name of the product is 
        System.out.println("Welcome to the Math Machine");
        
        // Starting a while loop for the menu untill they want exit
        while (choice != 11) {
            // Showing them the menu
            menu();
            
            // Telling them to pick one of the menu
            System.out.print("Pick: ");
            choice = input.nextInt();
            
            //Telling them what they picked
            System.out.println("\nYou picked " + choice + (":\n"));
            
            // If they pick 1
            if (choice == 1) {
                // Telling them what this option does
                System.out.println("To find the Sphere's Volume enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                System.out.print("Radius: ");
                radiusSphere = input.nextInt();

                System.out.print("Units: ");
                unit = input.next();
                
                // Using the method sphereVol and returning the answer to the variable vol
                vol = sphereVol(radiusSphere);
                
                // Displaying the answer to the user
                System.out.println("\nThe Volume of the Sphere is " + vol + " " + unit + " Cubed\n");
            }
            
            // If they pick 2
            if (choice == 2) {
                // Telling them what this option does
                System.out.println("To find the Perimeter of a Triangle enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                for (int i = 0; i < 3; i = i + 1) {
                    System.out.print("Side " + (i + 1) + ": ");
                    sidesTri[i] = input.nextInt();
                }
                
                System.out.print("Unit: ");
                unit = input.next();
                
                // Using the method trianglePerimeter and returning the answer to the variable perimeter
                perimeterTri = trianglePerimeter(sidesTri[0],sidesTri[1],sidesTri[2]);
                
                // Displaying the answer to the user
                System.out.println("\nThe Perimeter of the Triangle is " + perimeterTri + " " + unit + "\n");
            }
            
            // If they pick 3
            if (choice == 3) {
                // Telling them what this option does
                System.out.println("To find the Graphs Lines Length enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                System.out.print("Point one X: ");
                point1x = input.nextInt();
                
                System.out.print("point One Y: " );
                point1y = input.nextInt();
                
                System.out.print("point Two X: " );
                point2x = input.nextInt();
                
                System.out.print("point Two Y: " );
                point2y = input.nextInt();
                
                // Using the method findSlope and returning the answer to the variable slope
                graphLine = graphLineLen(point1x ,point1y ,point2x ,point2y);
                
                // Displaying the answer to the user
                System.out.println("\nThe Graphs Lines Length is " + graphLine + " Units\n");
            }
            
            // If they pick 4
            if (choice == 4) {
                // Telling them what this option does
                System.out.println("To find the Area of the Rectangle enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                System.out.print("Width: ");
                widthRecArea = input.nextInt();
                
                System.out.print("Length: ");
                lengthRecArea = input.nextInt();
                
                System.out.print("Units: ");
                unit = input.next();
                
                // Using the method rectangleArea and returning the answer to the variable area
                area = rectangleArea(widthRecArea,lengthRecArea);
                
                // Displaying the answer to the user
                System.out.println("\nThe Area of the Rectangle is " + area + " " + unit + " Squared\n");
            }
            
            // If they pick 5
            if (choice == 5) {
                // Telling them what this option does
                System.out.println("To find the Surface Area of the cube enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                System.out.print("Side length: ");
                sideLen = input.nextInt();
                
                System.out.print("Units: ");
                unit = input.next();
                
                // Using the method cubeSurArea and returning the answer to the variable surArea
                surArea = cubeSurArea(sideLen);
                
                // Displaying the answer to the user
                System.out.println("\nThe Surface Area is " + surArea + " " + unit + " Squared\n");
            }
            
            // If they pick 6
            if (choice == 6) {
                // Telling them what this option does
                System.out.println("To find the Rectangular Prism's Volume enter the Information Bellow:\n");
                
                // Getting them to fill the required information
                System.out.print("Length: ");
                lengthRecVol = input.nextInt();
                
                System.out.print("Width: ");
                widthRecVol = input.nextInt();
                
                System.out.print("Height: ");
                heightRecVol = input.nextInt();
                
                System.out.print("Unit: ");
                unit = input.next();
                
                // Using the method recVol and returning the answer to the variable recVolAns
                recVolAns = recVol(lengthRecVol,widthRecVol,heightRecVol);
                
                // Displaying the answer to the user
                System.out.println("\nThe Rectangular Prism Volume is " + recVolAns + " " + unit + " Cubed\n");
            }
            
            // If they pick 7
            if (choice == 7) {
                // telling Them what this option does
                System.out.println("To find the Perimeter of the Pentagon enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                for (int i = 0; i < 5; i = i + 1) {
                    System.out.print("Side " + (i + 1) + ": ");
                    sidesPen[i] = input.nextInt();
                }
                
                System.out.print("Unit: ");
                unit = input.next();
                
                // Using the method perimeterPentagon and returning the answer to the variable penPerimeter
                perimeterPen = perimeterPentagon(sidesPen[0],sidesPen[1],sidesPen[2],sidesPen[3],sidesPen[4]);
                
                // Displaying the answer to the user
                System.out.println("\nThe Perimeter of the Pentagon is " + perimeterPen + " " + unit + "\n");
            }
            
            // If they pick 8
            if (choice == 8) {
                // telling them what this option does
                System.out.println("to find the Area of the Triangle enter the Information Bellow:\n");
                
                // Getting them to fill in the required information
                System.out.print("Base: ");
                baseTri = input.nextInt();
                
                System.out.print("Height: ");
                heightTri = input.nextInt();
                
                System.out.print("Unit: ");
                unit = input.next();
                
                // Using the method triArea and returning the answer to the variable TriAreaAns
                triAreaAns = triArea(baseTri,heightTri);
                
                // Displaying the answer to the user
                System.out.println("\nThe Area of the Triangle is " + triAreaAns + " " + unit + " Squared\n");
            }
            
            // If they pick 9
            if (choice == 9) {
                // telling them what this option does
                System.out.println("To find the Surface Area of the Squared Based Triangular Pyrimid enter the Information Bellow:\n");
                
                // Getting them to enter the required information
                System.out.print("Square Side Length: ");
                sqSideLen = input.nextInt();
                
                System.out.print("Height of the Triangle Sides: ");
                pyrHeight = input.nextInt();
                
                System.out.print("Unit: ");
                unit = input.next();
                
                // Using the method triPyrSurAraea and returning the answer to the variable surAreaPyr
                surAreaPyr = triPyrSurArea(sqSideLen,pyrHeight);
                
                // Displaying the answer to the user
                System.out.println("\nThe Surface Area of the Square Based Triangular Pyrimid is " + surAreaPyr + " " + unit + " Squared\n");
            }
            
            // If they pick 10
            if (choice == 10) {
                // Telling them what this option does
                System.out.println("To find the Surface Area of the Cylinder enter the Information Bellow:\n");
                
                // Getting the required information
                System.out.print("Radius: ");
                radiusCylinder = input.nextInt();
                
                System.out.print("Height: ");
                heightCylinder = input.nextInt();
                
                System.out.print("Unit: ");
                unit = input.next();
                
                // Using the method cylSurArea and returning the answer to the variable surAreaCylinder
                surAreaCylinder = cylSurArea(radiusCylinder,heightCylinder);
                
                // Displaying the answer to the user
                System.out.println("\nThe Surface Area of the Cylinder is " + surAreaCylinder + " " + unit + " Squared\n");
            }
            
            // If they pick 6
            if (choice == 11) {
                // Telling them what this option does
                System.out.println("Thank you for using the Math Machine.");
                
                // Exiting the while loop
                break;
            }
            
            // If they pick a number above 6
            if (choice > 11 || choice < 1) {
                // Telling them the number they picked is invalid
                System.out.println("INVALID NUMBER TRY AGAIN\n");
            }
      
    }
    
}
}
