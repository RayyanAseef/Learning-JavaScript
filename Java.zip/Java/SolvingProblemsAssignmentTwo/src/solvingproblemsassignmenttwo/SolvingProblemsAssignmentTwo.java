/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solvingproblemsassignmenttwo;

import java.util.Scanner;

/**
 *
 * @author S300062235
 */
public class SolvingProblemsAssignmentTwo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner keyedInput = new Scanner(System.in);
        
        double length;
        double width;
        double height;
        double answer;
        
        System.out.println("Area of Pyrimid: (Length x Width x Height) / 3\n");
        System.out.println("Enter numbers of your choice bellow\n");
        
        System.out.print("Length: ");
        length = keyedInput.nextInt();
        
        System.out.print("Width: ");
        width = keyedInput.nextInt();
        
        System.out.print("Height: ");
        height = keyedInput.nextInt();
        
        answer = (length * width * height) / 3.0; 
        System.out.println("\nThe anwser is " + answer);
    }
    
}
