/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array1;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Array1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Making an input variable
        Scanner keyedInput = new Scanner(System.in);
        
        // Decalaring the variables
        int [] nums = new int[20];
        int total = 0;
        
        // Telling the user we are going to calculate 20 numbers they input
        System.out.println("This program will tell you the sum of the 20 numbers you enter.\n");
        
        // Getting 20 numbers from the user
        for (int i = 0;i <= 19;i = i + 1) {
            System.out.print("Number " + (i + 1) + ": ");
            nums[i] = keyedInput.nextInt();
        }
        
        // Getting the sum of the 20 number the user entered
        for (int i = 0;i <= 19;i = i + 1) {
            total = total + nums[i];
        }
        
        // Showing the user the sum of the 30 numbers the user entered
        System.out.println("\nThe total of the numbers you entered is " + total);
        
    }
    
}
